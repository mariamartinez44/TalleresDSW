//main.ts
import { series } from './data';
import { Serie } from './serie';

// Crear una función para generar la tabla
function createSeriesTable(series: Serie[]): void {
  // Crear los elementos básicos de la tabla
  const table = document.createElement('table');
  table.classList.add('series-table');

  // Crear la fila de encabezados
  const headerRow = document.createElement('tr');
  const headers = ['ID', 'Title', 'Channel', 'Seasons'];

  headers.forEach(headerText => {
    const header = document.createElement('th');
    header.textContent = headerText;
    headerRow.appendChild(header);
  });

  table.appendChild(headerRow);

  // Crear una fila para cada serie
  series.forEach(serie => {
    const row = document.createElement('tr');

    const idCell = document.createElement('td');
    idCell.textContent = serie.getId().toString();
    row.appendChild(idCell);

    const titleCell = document.createElement('td');
    titleCell.textContent = serie.getTitle();
    row.appendChild(titleCell);

    const channelCell = document.createElement('td');
    channelCell.textContent = serie.getChannel();
    row.appendChild(channelCell);

    const seasonsCell = document.createElement('td');
    seasonsCell.textContent = serie.getSeasons().toString();
    row.appendChild(seasonsCell);

    table.appendChild(row);
  });

  // Agregar la tabla a un contenedor existente en el HTML
  const tableContainer = document.getElementById('table-container');
  if (tableContainer) {
    tableContainer.appendChild(table);
  }
}

// Llamar a la función para crear la tabla con los datos de series
createSeriesTable(series);
